import { productosModel } from "../../models/candidatesHouseModel.js"

import { Op } from "sequelize"
// busqueda de todos los candidatos
//tenemos que incluir el as con el mismo valor para asociar el alias en la consulta
const getAllProducts = async () => {
    try {
        const productos = await productosModel.findAll();
        return [null, productos];
    } catch (error) {
        console.error(error);
        return [error.message, null];
    }
};
//busqueda por id

const getProductsById = async (id) => {
    try {
        const productos = await productosModel.findByPk(id);
        return [null, productos];
    }
    catch (error) {
        return [error.message, null];
    }
}

import productosModel from "../models/productosModel.js";

const createProducto = async (nombre, precio, categoria, disponible) => {
    if (
        nombre === undefined ||
        precio === undefined ||
        categoria === undefined ||
        disponible === undefined
    ) {
        const error = "Rellene todos los campos obligatorios.";
        return [error, null];
    }
    try {
        const producto = await productosModel.create({
            nombre,
            precio,
            categoria,
            disponible,
        });
        return [null, producto];
    } catch (e) {
        return [e.message, null];
    }
};

const updateProducto = async (id, nombre, precio, categoria, disponible) => {
    if (id === undefined) {
        const error = "Tienes que especificar un ID válido";
        return [error, null];
    }
    if (
        nombre === undefined ||
        precio === undefined ||
        categoria === undefined ||
        disponible === undefined
    ) {
        const error =
            "Los campos nombre, precio, categoría y disponibilidad son obligatorios.";
        return [error, null];
    }
    try {
        const producto = await productosModel.findByPk(id);
        producto.nombre = nombre;
        producto.precio = precio;
        producto.categoria = categoria;
        producto.disponible = disponible;
        producto.save();
        return [null, producto];
    } catch (e) {
        return [e.message, null];
    }
};

const removeProducto = async (id) => {
    try {
        const producto = await productosModel.findByPk(id);
        if (!producto) {
            const error = "No se ha encontrado ningún producto con ese ID.";
            return [error, null];
        }
        producto.destroy();
        return [null, producto];
    } catch (e) {
        return [e.message, null];
    }
};

export default{ createProducto, updateProducto, removeProducto, getAllProducts, getProductsById };
export { createProducto, updateProducto, removeProducto, getAllProducts, getProductsById };