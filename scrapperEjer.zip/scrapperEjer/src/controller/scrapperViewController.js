import scraperController from './scraperController.js';

const getAllProducts = async (req, res) => {
    const errorMessage = req.query.error;
    const [error, dogs] = await scraperController.getAllProducts();
    res.render("productos/list", {
        error: error || errorMessage,
        dogs,
        session: req.session,
    });
};

const getProductsById = async (req, res) => {
    const id = req.params.id;
    const [error, dog] = await scraperController.getById(id);
    res.render("productos/show", { error, dog, session: req.session });
};
const createForm = async (req, res) => {
    const error = req.query.error;
   
    res.render("productos/new", { error });
};

const create = async (req, res) => {
    const { nombre, precio, categoria, disponible } = req.body;
    

    const [error, producto] = await createProducto(nombre, precio, categoria, disponible);
    if (error) {
        const uriError = encodeURIComponent(error);
        return res.redirect(`/productos/new?error=${uriError}`);
    }
    res.redirect("/productos");
};

const updateForm = async (req, res) => {
    const errorMessage = req.query.error;
    const id = req.params.id;
   
    res.render("productos/edit", { error: errorMessage, producto, session: req.session });
};

const update = async (req, res) => {
    const id = req.params.id;
    const { nombre, precio, categoria, disponible } = req.body;
    const [error, producto] = await updateProducto(id, nombre, precio, categoria, disponible);
    if (error) {
        const uriError = encodeURIComponent(error);
        return res.redirect(`/productos/${id}/edit?error=${uriError}`);
    }
    res.redirect("/productos");
};

const remove = async (req, res) => {
    const id = req.params.id;

    const [deleteError, deletedProducto] = await removeProducto(id);
    if (deleteError) {
        const uriError = encodeURIComponent(deleteError);
        return res.redirect(`/productos?error=${uriError}`);
    }
    res.redirect("/productos");
};

export default {
    create,
    createForm,
    update,
    updateForm,
    remove, getAllProducts, getProductsById
};