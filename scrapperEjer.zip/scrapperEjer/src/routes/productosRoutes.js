import { Router } from "express";
import scrapperViewController from "../controller/scrapperViewController.js";

const router = Router();
router.get("/new", scrapperViewController.createForm);

router.post("/",(req,res)=>{
    scrapperViewController.create(req,res);
});


router.get("/:id/edit", scrapperViewController.updateForm);

router.get("/:id/delete",(req,res)=>{
    scrapperViewController.remove(req,res);
});
router.post("/:id",(req,res)=>{
    scrapperViewController.update(req,res);
});


router.get("/:id",(req,res)=>{
    scrapperViewController.getProductsById(req,res);
});

router.get("/",(req,res)=>{
    scrapperViewController.getAllProducts(req,res);
});




export default router;
