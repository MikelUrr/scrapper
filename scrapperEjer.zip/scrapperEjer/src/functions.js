function concatString(array) {
    const solucion= array.join(" ");

    return solucion;
}

function findSubstringPositions(str, substring) {
    const positions = [];
    let index = str.indexOf(substring);
    while (index !== -1) {
        positions.push(index);
        index = str.indexOf(substring, index + 1);
    }
    return positions;
}

function nameSurnameAge(name,surname,age) {
    if (typeof name !== 'string' || typeof surname !== 'string' || typeof age !== 'number' || age < 0) {
        throw new Error('Formato de entrada inválido');
    }

    const objeto ={
        "name": name,
        "surname": surname,
        "age": age    }
        console.log(objeto)

        return objeto;
    
}

export{
    concatString,
    findSubstringPositions,
    nameSurnameAge
}

