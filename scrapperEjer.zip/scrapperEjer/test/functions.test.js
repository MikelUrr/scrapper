import sequelize from "../config/db.js";
import { getAllProducts, getProductsById } from "../controllers/productosController.js";
import productosModel from "../models/productosModel.js";

describe("Productos Controller Tests", () => {
  beforeEach(async () => {
    await sequelize.sync({ force: true }); // Sincroniza y crea las tablas en la base de datos de prueba
    // Insertar productos de prueba en la base de datos
    await productosModel.create({ nombre: "Producto 1", precio: 10.99, categoria: "Electrónica", disponible: true });
    await productosModel.create({ nombre: "Producto 2", precio: 15.99, categoria: "Hogar", disponible: false });
  });

  it("should get all productos", async () => {
    const [error, productos] = await getAllProducts();
    expect(error).toBeNull();
    expect(productos.length).toBe(2);
     expect(productos[0].nombre).toBe("Producto 1");
     expect(productos[0].precio).toBe(10.99);
     expect(productos[0].categoria).toBe("Electrónica");
     expect(productos[0].disponible).toBe(true);
     expect(productos[1].nombre).toBe("Producto 2");
     expect(productos[1].precio).toBe(15.99);
     expect(productos[1].categoria).toBe("Hogar");
     expect(productos[1].disponible).toBe(false);
  });

  it("should get producto by ID", async () => {
    const productos = await productosModel.findAll();
    const [error, producto] = await getProductsById(productos[0].id);
    expect(error).toBeNull();
    expect(producto.nombre).toBe("Producto 1");
    expect(productos[0].precio).toBe(10.99);
     expect(productos[0].categoria).toBe("Electrónica");
     expect(productos[0].disponible).toBe(true);
  });
});

afterAll(async () => {
  await sequelize.close(); // Cierra la conexión a la base de datos
});
